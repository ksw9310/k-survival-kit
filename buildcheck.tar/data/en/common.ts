import { CommonContent } from '@/types/content';

export const common: CommonContent = {
  nav: {
    home: 'Home',
    gettingStarted: 'Getting Started',
    dailyLife: 'Daily Life',
    health: 'Health',
    housing: 'Housing',
    culture: 'Culture',
    visa: 'Visa',
  },
  hero: {
    badge: '🎓 For International Students',
    title: 'Your',
    highlight: 'K-Survival',
    subtitle:
      'Everything you actually need to know about living in Korea — from arrival essentials to housing, health, and daily life.',
    primaryCta: 'Start Here',
    secondaryCta: 'View Housing Guide',
  },
  category: {
    title: 'Explore by Topic',
    subtitle: 'Start with the category you need most right now.',
  },
  footer: {
    title: 'K-Survival Kit 🎒',
    description: 'Practical guide for international students living in Korea.',
    disclaimer:
      'Prices, policies, and procedures may change. Always verify important details before acting.',
  },
};
