import { CommonContent } from '@/types/content';

export const common: CommonContent = {
  nav: {
    home: '首页',
    gettingStarted: '入门指南',
    dailyLife: '日常生活',
    health: '医疗',
    housing: '住房',
    culture: '文化',
    visa: '签证',
  },
  hero: {
    badge: '🎓 面向国际留学生',
    title: '你的',
    highlight: 'K-Survival',
    subtitle:
      '为你整理在韩国生活真正需要知道的内容——从初到韩国到住房、医疗和日常生活。',
    primaryCta: '从这里开始',
    secondaryCta: '查看住房指南',
  },
  category: {
    title: '按主题查看',
    subtitle: '先从你现在最需要的信息开始。',
  },
  footer: {
    title: 'K-Survival Kit 🎒',
    description: '为在韩国生活的国际留学生准备的实用指南。',
    disclaimer:
      '价格、政策和办理流程都可能变化。采取行动前请务必再次确认重要信息。',
  },
};
