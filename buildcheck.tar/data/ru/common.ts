import { CommonContent } from '@/types/content';

export const common: CommonContent = {
  nav: {
    home: 'Главная',
    gettingStarted: 'Начало',
    dailyLife: 'Быт',
    health: 'Здоровье',
    housing: 'Жильё',
    culture: 'Культура',
    visa: 'Виза',
  },
  hero: {
    badge: '🎓 Для иностранных студентов',
    title: 'Твой',
    highlight: 'K-Survival',
    subtitle:
      'Всё, что реально нужно знать о жизни в Корее — от первых шагов после приезда до жилья, здоровья и повседневной жизни.',
    primaryCta: 'Начать',
    secondaryCta: 'Смотреть жильё',
  },
  category: {
    title: 'Выбери тему',
    subtitle: 'Начни с той категории, которая нужна тебе прямо сейчас.',
  },
  footer: {
    title: 'K-Survival Kit 🎒',
    description: 'Практическое руководство для иностранных студентов в Корее.',
    disclaimer:
      'Цены, правила и процедуры могут меняться. Всегда перепроверяй важную информацию перед тем, как действовать.',
  },
};
