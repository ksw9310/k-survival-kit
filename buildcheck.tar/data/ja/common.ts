import { CommonContent } from '@/types/content';

export const common: CommonContent = {
  nav: {
    home: 'ホーム',
    gettingStarted: 'はじめに',
    dailyLife: '日常生活',
    health: '医療',
    housing: '住居',
    culture: '文化',
    visa: 'ビザ',
  },
  hero: {
    badge: '🎓 留学生のために',
    title: 'あなたの',
    highlight: 'K-Survival',
    subtitle:
      '韓国での生活に本当に必要な情報をまとめました。到着後の準備から住居、医療、日常生活まで一通り確認できます。',
    primaryCta: 'ここから始める',
    secondaryCta: '住居ガイドを見る',
  },
  category: {
    title: 'テーマ別に見る',
    subtitle: '今いちばん必要なカテゴリから始めてください。',
  },
  footer: {
    title: 'K-Survival Kit 🎒',
    description: '韓国で暮らす留学生のための実用ガイドです。',
    disclaimer:
      '料金、制度、手続きは変わることがあります。行動する前に必ず重要な情報を再確認してください。',
  },
};
