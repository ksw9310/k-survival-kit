export type InfoCardItem = {
  emoji: string;
  title: string;
  description: string;
  bullets: string[];
  tip: string;
};

export type PageContent = {
  slug: string;
  eyebrow: string;
  title: string;
  subtitle: string;

  steps?: StepSection[];

  stepsHeading?: {
    eyebrow: string;
    title: string;
  };

  cards: InfoCardItem[];
};

export type CommonContent = {
  nav: {
    home: string;
    gettingStarted: string;
    dailyLife: string;
    health: string;
    housing: string;
    culture: string;
    visa: string;
  };
  hero: {
    badge: string;
    title: string;
    highlight: string;
    subtitle: string;
    primaryCta: string;
    secondaryCta: string;
  };
  category: {
    title: string;
    subtitle: string;
  };
  footer: {
    title: string;
    description: string;
    disclaimer: string;
  };
};

export type CategoryLinkItem = {
  href: string;
  title: string;
  description: string;
};

export type HomeContent = {
  introTitle: string;
  introDesc: string;
  categories: CategoryLinkItem[];
};

export type StepItem = {
  title: string;
  bullets: string[];
};

export type StepSection = {
  emoji: string;
  label: string;
  title: string;
  items: StepItem[];
};
