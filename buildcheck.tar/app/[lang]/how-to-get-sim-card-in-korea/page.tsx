import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { isValidLocale } from '@/lib/i18n';
import ArticleHero from '@/components/ArticleHero';
import PageDisclaimer from '@/components/PageDisclaimer';
import RelatedPosts from '@/components/RelatedPosts';
import AffiliateBanner from '@/components/AffiliateBanner';
import GuideToProBridge from '@/components/GuideToProBridge';
import { getGuideToProMap } from '@/data/pro-tools';

// TODO: Replace href with Airalo affiliate link once approved
const AIRALO_AFFILIATE_URL = 'https://www.airalo.com/korea-esim';

type Props = {
  params: Promise<{ lang: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { lang } = await params;

  if (!isValidLocale(lang)) {
    return {};
  }

  const url = `https://k-survival-kit.vercel.app/${lang}/how-to-get-sim-card-in-korea`;

  return {
    title: 'How to Get a SIM Card in Korea (2026 Guide) | K-Survival Kit',
    description:
      'Struggling to get a SIM card in Korea? This guide shows foreigners and international students the easiest way to buy a SIM at the airport, compare plans, and avoid common mistakes.',
    alternates: {
      canonical: url,
      languages: {
        en: '/en/how-to-get-sim-card-in-korea',
        zh: '/zh/how-to-get-sim-card-in-korea',
        ru: '/ru/how-to-get-sim-card-in-korea',
        ja: '/ja/how-to-get-sim-card-in-korea',
      },
    },
    openGraph: {
      title: 'How to Get a SIM Card in Korea (2026 Guide)',
      description:
        'Learn where to buy a SIM card in Korea, what it costs, and which option is best for international students.',
      url,
      type: 'article',
      siteName: 'K-Survival Kit',
      locale: lang,
    },
    twitter: {
      card: 'summary_large_image',
      title: 'How to Get a SIM Card in Korea (2026 Guide)',
      description:
        'A practical SIM card guide for foreigners and international students in Korea.',
    },
  };
}

export default async function SimCardGuidePage({ params }: Props) {
  const { lang } = await params;

  if (!isValidLocale(lang)) {
    notFound();
  }

  const guideToPro = getGuideToProMap(lang);

  return (
    <>
      <ArticleHero
        eyebrow="생활 가이드 / SIM Card Guide"
        title="How to Get a SIM Card in Korea for Foreigners (2026 Guide)"
        lead="If you are a foreigner or international student arriving in Korea, getting a Korean phone number early makes life much easier. A SIM card in Korea is often needed for delivery apps, banking, account verification, and everyday communication."
      />
      <PageDisclaimer type="general" />
      <main className="bg-slate-50 px-6 py-12">
      <article className="mx-auto max-w-4xl space-y-10">

        <p className="leading-7 text-slate-700">
          A SIM card in Korea is essential for foreigners and international
          students who want to use delivery apps, open bank accounts, and verify
          online services.
        </p>

        <section className="rounded-2xl border border-slate-200 bg-slate-50 p-6">
          <h2 className="text-2xl font-bold text-slate-900">Quick Answer</h2>
          <p className="mt-3 leading-7 text-slate-700">
            The easiest way to get a SIM card in Korea is to buy one at Incheon
            Airport or reserve one online for airport pickup. Most international
            students start with a prepaid SIM card or eSIM, then compare monthly
            plans later if they stay long-term.
          </p>
        </section>

        <AffiliateBanner
          icon="📱"
          title="Get a Korea eSIM Before You Land"
          description="Airalo lets you buy a Korea eSIM online and activate it before your flight. No airport queues, no physical SIM needed — just scan a QR code and you're connected the moment you land."
          href={AIRALO_AFFILIATE_URL}
          ctaText="Browse Korea eSIM Plans"
          accentColor="rose"
        />

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Where to Buy a SIM Card in Korea
          </h2>

          <p className="leading-7 text-slate-700">
            The easiest places to buy a SIM card in Korea are Incheon Airport,
            telecom stores, and some convenience stores. Most travelers and new
            students choose the airport first because it is simple and fast.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Incheon Airport telecom counters</li>
            <li>Official KT, SKT, and LG U+ stores</li>
            <li>Some convenience stores and travel SIM sellers</li>
            <li>Online reservation with airport pickup</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Main Telecom Companies in Korea
          </h2>

          <p className="leading-7 text-slate-700">
            The three major telecom providers are KT, SKT, and LG U+. All are
            commonly used in Korea and usually offer tourist SIM cards, prepaid
            plans, and data options.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>
              <strong>KT:</strong> often easy for foreigners and airport pickup
            </li>
            <li>
              <strong>SKT:</strong> strong brand and wide coverage
            </li>
            <li>
              <strong>LG U+:</strong> sometimes good prepaid options
            </li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            How Much Does a SIM Card Cost in Korea?
          </h2>

          <p className="leading-7 text-slate-700">
            A SIM card in Korea usually costs around 30,000 to 60,000 KRW,
            depending on the data amount, call options, and length of use. eSIM
            and prepaid plans may have slightly different prices.
          </p>

          <p className="leading-7 text-slate-700">
            If you stay for a short period, a prepaid tourist SIM is usually the
            easiest choice. If you stay longer, you may want to compare monthly
            plans after getting your ARC.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Best Option for International Students
          </h2>

          <p className="leading-7 text-slate-700">
            For most international students, the best first step is a prepaid
            SIM card or eSIM. It is fast, simple, and does not require much
            setup on your first day in Korea.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Short stay: prepaid SIM or eSIM</li>
            <li>Long stay: monthly plan after settling in</li>
            <li>Bring your passport when buying</li>
            <li>Some long-term plans may require an ARC later</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            eSIM vs Physical SIM
          </h2>

          <p className="leading-7 text-slate-700">
            eSIM is convenient because you do not need to insert a physical
            card. However, not every phone supports eSIM. A physical SIM is
            still the most common option for many new arrivals.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>eSIM: fast setup, no card needed</li>
            <li>Physical SIM: more common, easy to find</li>
            <li>Check your phone compatibility before buying</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            What You Need to Buy
          </h2>

          <p className="leading-7 text-slate-700">
            In most cases, you should bring your passport. For some long-term
            mobile plans in Korea, additional documents may be required later.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Practical Tips Before You Buy
          </h2>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Buy at the airport if you want the easiest first-day setup</li>
            <li>Compare data limits before choosing a plan</li>
            <li>Check whether tethering is included</li>
            <li>Make sure your phone is unlocked</li>
            <li>Keep your receipt and SIM packaging for support</li>
          </ul>
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-6">
          <h2 className="text-2xl font-bold text-slate-900">Final Advice</h2>
          <p className="mt-3 leading-7 text-slate-700">
            If you are new to Korea, do not overthink it. Start with the easiest
            SIM card in Korea that gives you data and a Korean number quickly.
            After that, you can switch to a more suitable plan once you
            understand your needs better.
          </p>
        </section>

        <GuideToProBridge lang={lang} tool={guideToPro['how-to-get-sim-card-in-korea']} />

        <section className="space-y-4">

          <h2 className="text-2xl font-bold text-slate-900">
            What to Do After Getting Your SIM Card
          </h2>

          <p className="leading-7 text-slate-700">
            After setting up your SIM card in Korea, the next steps usually
            include getting your ARC card and opening a bank account.
          </p>

          <ul className="list-disc pl-6 space-y-2 text-slate-700">
            <li>
              <a
                href={`/${lang}/arc-card-korea-guide`}
                className="text-blue-600 underline"
              >
                ARC Card Guide
              </a>
            </li>
            <li>
              <a
                href={`/${lang}/best-bank-account-for-foreigners-korea`}
                className="text-blue-600 underline"
              >
                Bank Account Guide
              </a>
            </li>
            <li>
              <a
                href={`/${lang}/korea-delivery-apps-guide`}
                className="text-blue-600 underline"
              >
                Delivery Apps Guide
              </a>
            </li>
          </ul>
        </section>
        <section className="rounded-2xl bg-slate-900 p-6 text-white">
          <h2 className="text-2xl font-bold">Related Guides</h2>
          <p className="mt-3 text-slate-300">
            After getting your SIM card, the next important step is usually your
            ARC and basic setup for living in Korea.
          </p>

          <div className="mt-4 flex flex-wrap gap-3">
            <a
              href={`/${lang}/getting-started`}
              className="rounded-xl bg-white px-4 py-2 font-semibold text-slate-900"
            >
              Getting Started
            </a>
            <a
              href={`/${lang}/housing`}
              className="rounded-xl border border-white/30 px-4 py-2 font-semibold text-white"
            >
              Housing Guide
            </a>
          </div>
        </section>
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">FAQ</h2>

          <div className="space-y-4 text-slate-700">
            <div>
              <h3 className="font-semibold">
                Can foreigners buy a SIM card in Korea?
              </h3>
              <p>
                Yes, foreigners can easily buy a SIM card in Korea. Most people
                purchase one at Incheon Airport or telecom stores using their
                passport.
              </p>
            </div>

            <div>
              <h3 className="font-semibold">
                Do I need an ARC to get a SIM card in Korea?
              </h3>
              <p>
                No, you do not need an ARC for prepaid SIM cards. However,
                long-term mobile plans usually require an ARC.
              </p>
            </div>

            <div>
              <h3 className="font-semibold">
                Which SIM card is best for international students in Korea?
              </h3>
              <p>
                Most international students start with a prepaid SIM or eSIM
                because it is quick and does not require complicated setup.
              </p>
            </div>
          </div>
        </section>
      </article>
      <RelatedPosts lang={lang as string} current="how-to-get-sim-card-in-korea" />
      </main>
    </>
  );
}
