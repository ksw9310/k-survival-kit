import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import ArticleHero from '@/components/ArticleHero';
import PageDisclaimer from '@/components/PageDisclaimer';
import ProExecutionWorkspace from '@/components/ProExecutionWorkspace';
import { getProTool, proTools } from '@/data/pro-tools';
import { isValidLocale, locales } from '@/lib/i18n';

/**
 * Design reminder for this file:
 * This page must feel like a dedicated Pro tool workspace.
 * The public guide remains adjacent in meaning but separate in experience.
 * Every visible section should reinforce action, progress, and continuity.
 */

type Props = {
  params: Promise<{ lang: string; slug: string }>;
};

export function generateStaticParams() {
  return locales.flatMap((lang) =>
    proTools.map((tool) => ({ lang, slug: tool.slug })),
  );
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { lang, slug } = await params;

  if (!isValidLocale(lang)) {
    return {};
  }

  const tool = getProTool(slug);

  if (!tool) {
    return {};
  }

  return {
    title: `${tool.title} | K-Survival Kit Pro`,
    description: tool.summary,
    alternates: {
      canonical: `https://k-survival-kit.vercel.app/${lang}/pro/${tool.slug}`,
    },
    openGraph: {
      title: `${tool.title} | K-Survival Kit Pro`,
      description: tool.summary,
      url: `https://k-survival-kit.vercel.app/${lang}/pro/${tool.slug}`,
      type: 'website',
      locale: lang,
      siteName: 'K-Survival Kit',
    },
  };
}

export default async function ProToolDetailPage({ params }: Props) {
  const { lang, slug } = await params;

  if (!isValidLocale(lang)) {
    notFound();
  }

  const tool = getProTool(slug);

  if (!tool) {
    notFound();
  }

  const relatedTools = proTools.filter((entry) => entry.slug !== tool.slug).slice(0, 3);

  return (
    <>
      <ArticleHero eyebrow={tool.eyebrow} title={tool.title} lead={tool.summary} />
      <PageDisclaimer type="general" />

      <main className="bg-slate-50 px-6 py-10 md:py-14">
        <article className="mx-auto max-w-6xl space-y-8">
          <section className="overflow-hidden rounded-[2rem] border border-slate-200 bg-white shadow-sm">
            <div className="grid gap-6 border-b border-slate-200 bg-[linear-gradient(135deg,#0f172a_0%,#172554_52%,#111827_100%)] px-6 py-7 text-white md:px-8 md:py-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-end">
              <div className="max-w-3xl">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="rounded-full border border-white/15 bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-slate-100">
                    Separate Pro workspace
                  </span>
                  <span className="rounded-full border border-amber-300/25 bg-amber-300/10 px-3 py-1 text-xs font-semibold text-amber-100">
                    Linked to {tool.guideTitle}
                  </span>
                </div>

                <h2 className="mt-5 max-w-3xl text-3xl font-bold tracking-tight md:text-4xl">
                  This is the action layer, not the article.
                </h2>
                <p className="mt-4 max-w-3xl text-base leading-7 text-slate-200 md:text-lg">
                  {tool.executionSummary} Use the public guide for explanation and policy context. Use this workspace when you want to track real progress and keep your next step visible.
                </p>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <Link
                  href={`/${lang}${tool.guideHref}`}
                  className="inline-flex items-center justify-center rounded-2xl border border-white/20 bg-white/10 px-5 py-3 text-sm font-semibold text-white transition hover:bg-white/15"
                >
                  Return to public guide
                </Link>
                <Link
                  href={`/${lang}`}
                  className="inline-flex items-center justify-center rounded-2xl bg-white px-5 py-3 text-sm font-semibold text-slate-950 transition hover:bg-rose-50"
                >
                  Explore other guides
                </Link>
              </div>
            </div>

            <div className="grid gap-4 bg-slate-50 p-6 md:grid-cols-3 md:p-8">
              <div className="rounded-2xl border border-slate-200 bg-white p-5">
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
                  What Pro changes
                </p>
                <p className="mt-4 text-lg font-semibold text-slate-950">Persistent workflow</p>
                <p className="mt-2 text-sm leading-6 text-slate-600">
                  This page is structured as a workspace that remembers progress on this browser.
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-5">
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
                  Best fit
                </p>
                <p className="mt-4 text-lg font-semibold text-slate-950">{tool.highlight}</p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white p-5">
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
                  Continue path
                </p>
                <p className="mt-4 text-lg font-semibold text-slate-950">
                  {tool.nextToolTitle ? `Next: ${tool.nextToolTitle}` : 'Stay in this workspace'}
                </p>
                <p className="mt-2 text-sm leading-6 text-slate-600">
                  Finish the current tasks, then move laterally to the next related Pro step without restarting from the homepage.
                </p>
              </div>
            </div>
          </section>

          <ProExecutionWorkspace lang={lang} tool={tool} relatedTools={relatedTools} />
        </article>
      </main>
    </>
  );
}
