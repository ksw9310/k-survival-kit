import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { isValidLocale } from '@/lib/i18n';
import ArticleHero from '@/components/ArticleHero';
import PageDisclaimer from '@/components/PageDisclaimer';
import RelatedPosts from '@/components/RelatedPosts';
import GuideToProBridge from '@/components/GuideToProBridge';
import { getGuideToProMap } from '@/data/pro-tools';

type Props = {
  params: Promise<{ lang: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { lang } = await params;

  if (!isValidLocale(lang)) {
    return {};
  }

  const url = `https://k-survival-kit.vercel.app/${lang}/arc-card-korea-guide`;

  return {
    title:
      'ARC Card Korea Guide for International Students (2026) | K-Survival Kit',
    description:
      'Need an ARC card in Korea? This guide explains what it is, when to apply, required documents, and how international students can avoid delays and confusion.',
    alternates: {
      canonical: url,
      languages: {
        en: '/en/arc-card-korea-guide',
        zh: '/zh/arc-card-korea-guide',
        ru: '/ru/arc-card-korea-guide',
        ja: '/ja/arc-card-korea-guide',
      },
    },
    openGraph: {
      title: 'ARC Card Korea Guide for International Students (2026)',
      description:
        'Learn what the ARC card is, when to apply, what documents you need, and how the process works in Korea.',
      url,
      type: 'article',
      siteName: 'K-Survival Kit',
      locale: lang,
    },
    twitter: {
      card: 'summary_large_image',
      title: 'ARC Card Korea Guide for International Students (2026)',
      description:
        'A practical ARC guide for foreigners and students living in Korea.',
    },
  };
}

export default async function ArcCardGuidePage({ params }: Props) {
  const { lang } = await params;

  if (!isValidLocale(lang)) {
    notFound();
  }

  const guideToPro = getGuideToProMap(lang);

  return (
    <>
      <ArticleHero
        eyebrow="비자 / ARC Guide"
        title="ARC Card Korea Guide for International Students (2026)"
        lead="If you plan to stay in Korea for more than a short period, the ARC card is one of the most important documents you will need. This guide explains what it is, why it matters, and how international students can prepare for the process."
      />
      <PageDisclaimer type="general" />
      <main className="bg-slate-50 px-6 py-12">
      <article className="mx-auto max-w-4xl space-y-10">

        <section className="rounded-2xl border border-slate-200 bg-slate-50 p-6">
          <h2 className="text-2xl font-bold text-slate-900">Quick Answer</h2>
          <p className="mt-3 leading-7 text-slate-700">
            The ARC, often called the Alien Registration Card or residence card,
            is an essential ID for foreigners living in Korea. International
            students usually need it for banking, phone plans, insurance, and
            many official services.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            What Is an ARC Card in Korea?
          </h2>

          <p className="leading-7 text-slate-700">
            The ARC card in Korea is the identification card used by registered
            foreign residents. It helps prove your legal stay and is often
            required for important daily tasks after arrival.
          </p>

          <p className="leading-7 text-slate-700">
            Even if people still say “ARC,” the terminology and procedures may
            change over time, so always check the most current official guidance
            before applying.
          </p>
        </section>

        <p className="leading-7 text-slate-700">
          The ARC card in Korea is one of the most important steps for
          foreigners and international students who plan to stay long-term and
          use local services.
        </p>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Why the ARC Is Important
          </h2>

          <p className="leading-7 text-slate-700">
            For many international students, life in Korea becomes much easier
            after receiving the ARC card. Without it, some services can be
            limited or slower to access.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Opening a Korean bank account</li>
            <li>Signing up for longer mobile phone plans</li>
            <li>Using some financial and identity verification services</li>
            <li>Handling immigration-related updates more smoothly</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            When Should You Apply?
          </h2>

          <p className="leading-7 text-slate-700">
            If you are staying in Korea long-term, you usually need to register
            within the required period after arrival. International students
            should not wait until the last minute because reservation slots and
            processing times may vary.
          </p>

          <p className="leading-7 text-slate-700">
            The safest approach is to check your visa conditions early and begin
            preparing as soon as possible after entering Korea.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Common Documents You May Need
          </h2>

          <p className="leading-7 text-slate-700">
            Requirements can vary, but international students often prepare a
            similar set of documents before their ARC application.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Passport</li>
            <li>Visa-related documents</li>
            <li>School enrollment or admission documents</li>
            <li>Passport-style photo</li>
            <li>Application form or appointment confirmation</li>
            <li>Address information in Korea</li>
          </ul>

          <p className="leading-7 text-slate-700">
            Always confirm the latest checklist through the official immigration
            system or your school’s international office.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            How the ARC Process Usually Works
          </h2>

          <p className="leading-7 text-slate-700">
            The ARC process in Korea usually involves preparing documents,
            booking an appointment if needed, visiting the immigration office,
            submitting your application, and waiting for processing.
          </p>

          <ol className="list-decimal space-y-2 pl-6 text-slate-700">
            <li>Check the current requirements</li>
            <li>Prepare your documents carefully</li>
            <li>Book an appointment if required</li>
            <li>Visit the immigration office on time</li>
            <li>Submit documents and complete the process</li>
            <li>Wait for card issuance or delivery</li>
          </ol>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Common Mistakes to Avoid
          </h2>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Waiting too long before checking requirements</li>
            <li>Bringing incomplete documents</li>
            <li>Using outdated online information</li>
            <li>Missing your reservation or appointment time</li>
            <li>Assuming every visa follows the same process</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Useful Tips for International Students
          </h2>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Ask your university international office for help</li>
            <li>Prepare digital and printed copies of key documents</li>
            <li>Keep your Korean address written clearly</li>
            <li>Arrive early on appointment day</li>
            <li>Check official updates instead of relying only on blogs</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">FAQ</h2>

          <div className="space-y-4 text-slate-700">
            <div>
              <h3 className="font-semibold">What is an ARC card in Korea?</h3>
              <p>
                The ARC card in Korea is an ID card for foreign residents. It is
                required for many services such as banking, phone plans, and
                official verification.
              </p>
            </div>

            <div>
              <h3 className="font-semibold">
                Do international students need an ARC in Korea?
              </h3>
              <p>
                Yes, most international students staying long-term need to apply
                for an ARC after arriving in Korea.
              </p>
            </div>

            <div>
              <h3 className="font-semibold">
                How long does it take to get an ARC card?
              </h3>
              <p>
                Processing time can vary, but it usually takes a few weeks
                depending on the immigration office and application timing.
              </p>
            </div>
          </div>
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-6">
          <h2 className="text-2xl font-bold text-slate-900">Final Advice</h2>

          <p className="mt-3 leading-7 text-slate-700">
            The ARC card Korea process may feel complicated at first, but it is
            manageable if you prepare early and follow current guidance. For
            most international students, the best strategy is to handle the ARC
            application as one of the first major tasks after arrival.
          </p>
        </section>

        <GuideToProBridge lang={lang} tool={guideToPro['arc-card-korea-guide']} />

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            What to Do Before and After Getting Your ARC
          </h2>

          <p className="leading-7 text-slate-700">
            Before applying for your ARC card in Korea, it is helpful to prepare
            your SIM card and basic setup. After receiving your ARC, you can
            access more services like banking and mobile plans.
          </p>

          <ul className="list-disc pl-6 space-y-2 text-slate-700">
            <li>
              <a
                href={`/${lang}/how-to-get-sim-card-in-korea`}
                className="text-blue-600 underline"
              >
                SIM Card Guide
              </a>
            </li>
            <li>
              <a
                href={`/${lang}/best-bank-account-for-foreigners-korea`}
                className="text-blue-600 underline"
              >
                Bank Account Guide
              </a>
            </li>
            <li>
              <a
                href={`/${lang}/korea-delivery-apps-guide`}
                className="text-blue-600 underline"
              >
                Delivery Apps Guide
              </a>
            </li>
          </ul>
        </section>

        <section className="rounded-2xl bg-slate-900 p-6 text-white">
          <h2 className="text-2xl font-bold">Related Guides</h2>
          <p className="mt-3 text-slate-300">
            After checking the ARC process, you may also want to set up your SIM
            card and learn the basics of getting started in Korea.
          </p>

          <div className="mt-4 flex flex-wrap gap-3">
            <a
              href={`/${lang}/how-to-get-sim-card-in-korea`}
              className="rounded-xl bg-white px-4 py-2 font-semibold text-slate-900"
            >
              SIM Card Guide
            </a>
            <a
              href={`/${lang}/getting-started`}
              className="rounded-xl border border-white/30 px-4 py-2 font-semibold text-white"
            >
              Getting Started
            </a>
          </div>
        </section>
      </article>
      <RelatedPosts lang={lang as string} current="arc-card-korea-guide" />
      </main>
    </>
  );
}
