import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { isValidLocale } from '@/lib/i18n';
import ArticleHero from '@/components/ArticleHero';
import PageDisclaimer from '@/components/PageDisclaimer';
import RelatedPosts from '@/components/RelatedPosts';

type Props = {
  params: Promise<{ lang: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { lang } = await params;

  if (!isValidLocale(lang)) {
    return {};
  }

  const url = `https://k-survival-kit.vercel.app/${lang}/korea-delivery-apps-guide`;

  return {
    title:
      'Best Korea Delivery Apps for Foreigners (2026 Guide) | K-Survival Kit',
    description:
      'Not sure which Korea delivery app to use? Compare Baemin, Coupang Eats, and Yogiyo, and learn how foreigners can order food easily without getting stuck.',
    alternates: {
      canonical: url,
      languages: {
        en: '/en/korea-delivery-apps-guide',
        zh: '/zh/korea-delivery-apps-guide',
        ru: '/ru/korea-delivery-apps-guide',
        ja: '/ja/korea-delivery-apps-guide',
      },
    },
    openGraph: {
      title: 'Best Korea Delivery Apps for Foreigners (2026 Guide)',
      description:
        'Learn which Korea delivery apps are easiest for foreigners and international students, and how to use them without confusion.',
      url,
      type: 'article',
      siteName: 'K-Survival Kit',
      locale: lang,
    },
    twitter: {
      card: 'summary_large_image',
      title: 'Best Korea Delivery Apps for Foreigners (2026 Guide)',
      description:
        'A practical Korea food delivery guide for international students and foreigners.',
    },
  };
}

export default async function KoreaDeliveryAppsGuidePage({ params }: Props) {
  const { lang } = await params;

  if (!isValidLocale(lang)) {
    notFound();
  }

  return (
    <>
      <ArticleHero
        eyebrow="Daily Life / Delivery Apps Guide"
        title="Best Korea Delivery Apps for Foreigners (Baemin, Coupang Eats Guide)"
        lead="Food delivery in Korea is fast, common, and extremely convenient. But many foreigners and international students feel confused at first because the most popular Korea delivery apps are built mainly for local users. This guide explains the main apps, how they work, and what to watch out for."
      />
      <PageDisclaimer type="general" />
      <main className="bg-slate-50 px-6 py-12">
      <article className="mx-auto max-w-4xl space-y-10">

        <section className="rounded-2xl border border-slate-200 bg-slate-50 p-6">
          <h2 className="text-2xl font-bold text-slate-900">Quick Answer</h2>
          <p className="mt-3 leading-7 text-slate-700">
            The most well-known Korea delivery apps are <strong>Baemin</strong>,
            <strong> Coupang Eats</strong>, and <strong>Yogiyo</strong>. For
            many international students, Baemin and Coupang Eats are the most
            useful starting points, but payment, phone verification, and address
            setup can sometimes be confusing if you are new to Korea.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Why Korea Delivery Apps Feel Different
          </h2>

          <p className="leading-7 text-slate-700">
            Korea delivery apps are not just for food. They are part of daily
            life, and people use them often because delivery is fast and widely
            available. However, many apps assume that you already have a Korean
            phone number, a local payment method, and a clear Korean address.
          </p>

          <p className="leading-7 text-slate-700">
            That is why many foreigners can download an app but still get stuck
            during sign-up, payment, or address entry.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            1. Baemin (Baedal Minjok)
          </h2>

          <p className="leading-7 text-slate-700">
            Baemin is one of the most popular Korea delivery apps. It has a huge
            number of restaurants and is widely used in many cities. If you ask
            people in Korea which delivery app they use most often, Baemin is
            usually one of the first names you will hear.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Very large restaurant selection</li>
            <li>Popular in daily life</li>
            <li>Good for comparing many nearby stores</li>
            <li>May feel more Korean-language focused for beginners</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">2. Coupang Eats</h2>

          <p className="leading-7 text-slate-700">
            Coupang Eats is another major Korea delivery app and is often seen
            as simple and convenient. Some users prefer it because the app flow
            can feel cleaner, and promotions or discounts may appear depending
            on the area.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Often simple to browse</li>
            <li>Sometimes strong promotion offers</li>
            <li>Useful if you already use other Coupang services</li>
            <li>Availability can vary by neighborhood</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">3. Yogiyo</h2>

          <p className="leading-7 text-slate-700">
            Yogiyo is another well-known Korea delivery app and has been used by
            many residents for years. Depending on your area, it may still be a
            useful option, especially when comparing restaurant availability and
            prices.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Recognized food delivery platform</li>
            <li>Useful as an alternative when comparing apps</li>
            <li>Restaurant availability depends on area</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            What You Usually Need Before Ordering
          </h2>

          <p className="leading-7 text-slate-700">
            Most Korea delivery apps work more smoothly after you have basic
            local setup completed.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>A Korean phone number</li>
            <li>A clear delivery address in Korea</li>
            <li>A local card or supported payment method</li>
            <li>Basic understanding of your building or dorm location</li>
          </ul>

          <p className="leading-7 text-slate-700">
            Without these, the app may still open, but actual ordering can be
            frustrating.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Common Problems Foreigners Face
          </h2>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Phone number verification issues</li>
            <li>Address entry confusion</li>
            <li>Korean-only instructions from stores</li>
            <li>Payment method not working</li>
            <li>Not understanding delivery requests or notes</li>
          </ul>

          <p className="leading-7 text-slate-700">
            These problems are normal at first. Most new students need a little
            time before ordering becomes easy.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            How to Make Delivery Easier
          </h2>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Set up your Korean phone number early</li>
            <li>Save your address carefully and double-check it</li>
            <li>Use simple delivery notes if needed</li>
            <li>Compare the same restaurant across different apps</li>
            <li>Start with popular chain stores if you want fewer surprises</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Which Delivery App Is Best for International Students?
          </h2>

          <p className="leading-7 text-slate-700">
            There is no perfect single answer, but many international students
            start with <strong>Baemin</strong> or <strong>Coupang Eats</strong>.
            The best choice often depends on where you live, whether you already
            have a Korean number, and which app feels easiest for you to use.
          </p>

          <p className="leading-7 text-slate-700">
            The practical approach is simple: install two apps, compare a few
            restaurants, and use the one that works best in your neighborhood.
          </p>
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-6">
          <h2 className="text-2xl font-bold text-slate-900">Final Advice</h2>

          <p className="mt-3 leading-7 text-slate-700">
            Korea delivery apps can feel difficult on day one, but they become
            one of the easiest parts of daily life once your phone number,
            address, and payment setup are ready. For most foreigners, the best
            strategy is to start simple, compare apps, and learn by using them a
            few times.
          </p>
        </section>

        <section className="rounded-2xl bg-slate-900 p-6 text-white">
          <h2 className="text-2xl font-bold">Related Guides</h2>
          <p className="mt-3 text-slate-300">
            These guides will help you use daily services in Korea more easily.
          </p>

          <div className="mt-4 flex flex-wrap gap-3">
            <a
              href={`/${lang}/how-to-get-sim-card-in-korea`}
              className="rounded-xl bg-white px-4 py-2 font-semibold text-slate-900"
            >
              SIM Card Guide
            </a>
            <a
              href={`/${lang}/getting-started`}
              className="rounded-xl border border-white/30 px-4 py-2 font-semibold text-white"
            >
              Getting Started
            </a>
          </div>
        </section>
      </article>
      <RelatedPosts lang={lang as string} current="korea-delivery-apps-guide" />
      </main>
    </>
  );
}
