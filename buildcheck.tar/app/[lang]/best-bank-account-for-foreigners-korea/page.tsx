import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { isValidLocale } from '@/lib/i18n';
import ArticleHero from '@/components/ArticleHero';
import PageDisclaimer from '@/components/PageDisclaimer';
import RelatedPosts from '@/components/RelatedPosts';
import AffiliateBanner from '@/components/AffiliateBanner';
import GuideToProBridge from '@/components/GuideToProBridge';
import { getGuideToProMap } from '@/data/pro-tools';

// TODO: Replace href with Wise affiliate link once approved via Partnerize
const WISE_AFFILIATE_URL = 'https://wise.com/invite/dic/kangsangukg1';

type Props = {
  params: Promise<{ lang: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { lang } = await params;

  if (!isValidLocale(lang)) {
    return {};
  }

  const url = `https://k-survival-kit.vercel.app/${lang}/best-bank-account-for-foreigners-korea`;

  return {
    title:
      'Best Bank Account for Foreigners in Korea (2026 Guide) | K-Survival Kit',
    description:
      'Opening a bank account in Korea as a foreigner? Learn the easiest way, required documents, and how international students can avoid common problems.',
    alternates: {
      canonical: url,
      languages: {
        en: '/en/best-bank-account-for-foreigners-korea',
        zh: '/zh/best-bank-account-for-foreigners-korea',
        ru: '/ru/best-bank-account-for-foreigners-korea',
        ja: '/ja/best-bank-account-for-foreigners-korea',
      },
    },
    openGraph: {
      title: 'Best Bank Account for Foreigners in Korea (2026 Guide)',
      description:
        'Learn how foreigners and international students can open a bank account in Korea and what to prepare before visiting a bank.',
      url,
      type: 'article',
      siteName: 'K-Survival Kit',
      locale: lang,
    },
    twitter: {
      card: 'summary_large_image',
      title: 'Best Bank Account for Foreigners in Korea (2026 Guide)',
      description:
        'A practical Korean bank account guide for foreigners and international students.',
    },
  };
}

export default async function BestBankAccountForForeignersKoreaPage({
  params,
}: Props) {
  const { lang } = await params;

  if (!isValidLocale(lang)) {
    notFound();
  }

  const guideToPro = getGuideToProMap(lang);

  return (
    <>
      <ArticleHero
        eyebrow="Banking / Daily Life Guide"
        title="Best Bank Account in Korea for Foreigners (Easy Setup Guide)"
        lead="Opening a bank account in Korea can feel confusing if you are new to the country. Many foreigners and international students need a Korean bank account for rent, transfers, part-time work, and daily payments, but the process may depend on your documents and visa status."
      />
      <PageDisclaimer type="general" />
      <main className="bg-slate-50 px-6 py-12">
      <article className="mx-auto max-w-4xl space-y-10">

        <AffiliateBanner
          icon="💸"
          title="Send Money to Korea (or Back Home) with Wise"
          description="Wise offers real exchange rates with low transparent fees — no hidden markups. Used by millions of international students worldwide for tuition payments, rent transfers, and sending money home."
          href={WISE_AFFILIATE_URL}
          ctaText="Try Wise for Free"
          accentColor="green"
        />

        <section className="rounded-2xl border border-slate-200 bg-slate-50 p-6">
          <h2 className="text-2xl font-bold text-slate-900">Quick Answer</h2>
          <p className="mt-3 leading-7 text-slate-700">
            The best bank account for foreigners in Korea usually depends on how
            long you are staying, whether you already have your ARC, and what
            services you need most. For many international students, the best
            option is a bank with a simple branch process, clear support for
            foreigners, and a usable mobile app.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Why You Need a Korean Bank Account
          </h2>

          <p className="leading-7 text-slate-700">
            A Korean bank account makes daily life much easier. Without one, you
            may struggle with transfers, online payments, tuition-related
            processes, mobile services, or receiving money in Korea.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Paying rent or deposits</li>
            <li>Receiving transfers from family or work</li>
            <li>Connecting with Korean payment systems</li>
            <li>Managing local spending more easily</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            What Makes a Bank Good for Foreigners?
          </h2>

          <p className="leading-7 text-slate-700">
            The best bank account for foreigners in Korea is not always about
            the biggest bank. The more important questions are whether the bank
            is comfortable working with foreign customers, whether the staff can
            explain the process clearly, and whether the app is practical for
            everyday use.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Foreigner-friendly account opening process</li>
            <li>Reasonable document requirements</li>
            <li>Useful mobile banking app</li>
            <li>Good branch access near your university or home</li>
            <li>Stable transfer and payment functions</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Common Documents You May Need
          </h2>

          <p className="leading-7 text-slate-700">
            The exact documents can vary depending on the bank and your status,
            but many foreigners are asked for a similar set of documents.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Passport</li>
            <li>ARC or proof of residence status</li>
            <li>Korean phone number</li>
            <li>
              Student certificate, school document, or address information
            </li>
          </ul>

          <p className="leading-7 text-slate-700">
            Some banks may be more flexible than others, but you should not
            assume the process is the same everywhere.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Can You Open a Bank Account Without an ARC?
          </h2>

          <p className="leading-7 text-slate-700">
            In some cases, a foreigner may be able to open a limited account
            without an ARC, but it is usually much easier after receiving the
            ARC. Many long-term functions become more practical once your
            identity and residence status are clearly confirmed in Korea.
          </p>

          <p className="leading-7 text-slate-700">
            If you have just arrived, the most realistic plan is often to get
            your basic setup done first and then visit the bank with the most
            complete documents possible.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Common Problems Foreigners Face at Korean Banks
          </h2>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Different document rules depending on the branch</li>
            <li>Language barrier during account explanation</li>
            <li>Restrictions on transfers or account features at first</li>
            <li>Difficulty setting up mobile banking</li>
            <li>Confusion about account purpose or transaction limits</li>
          </ul>

          <p className="leading-7 text-slate-700">
            This is why many students ask their school international office for
            advice before visiting a branch.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Practical Tips Before You Visit a Bank
          </h2>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Bring more documents than you think you need</li>
            <li>Visit a branch near a university or foreigner-heavy area</li>
            <li>Ask your school for support or a recommendation</li>
            <li>Go earlier in the day if possible</li>
            <li>Prepare your Korean address and phone number clearly</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Which Bank Is Best?
          </h2>

          <p className="leading-7 text-slate-700">
            There is no single perfect answer for everyone. The best bank
            account for foreigners in Korea depends on your location, document
            status, and what you need the account for. A bank that works well
            for a student in Seoul may not be the easiest choice for someone in
            another city.
          </p>

          <p className="leading-7 text-slate-700">
            In practice, the best choice is usually the bank that gives you the
            smoothest account opening experience, lets you manage money easily,
            and works well with your current documents.
          </p>
        </section>

        <p className="leading-7 text-slate-700">
          For many newcomers, finding the best bank account for foreigners in
          Korea is not about prestige but about which bank is easiest to open,
          easiest to use, and most realistic for your current documents.
        </p>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">FAQ</h2>

          <div className="space-y-4 text-slate-700">
            <div>
              <h3 className="font-semibold">
                Can foreigners open a bank account in Korea?
              </h3>
              <p>
                Yes, foreigners can open a bank account in Korea, but the
                process depends on the bank, your visa status, and the documents
                you bring.
              </p>
            </div>

            <div>
              <h3 className="font-semibold">
                Do I need an ARC to open a bank account in Korea?
              </h3>
              <p>
                In many cases, opening a bank account becomes easier after
                getting your ARC. Some banks may offer limited options before
                that, but it varies.
              </p>
            </div>

            <div>
              <h3 className="font-semibold">
                What is the best bank account for international students in
                Korea?
              </h3>
              <p>
                The best bank account for international students in Korea is
                usually the one that has a branch near campus, handles foreigner
                applications clearly, and offers a practical mobile banking app.
              </p>
            </div>
          </div>
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-6">
          <h2 className="text-2xl font-bold text-slate-900">Final Advice</h2>

          <p className="mt-3 leading-7 text-slate-700">
            If you are an international student, do not focus only on brand
            reputation. Focus on what is realistic right now: your documents,
            your school location, and whether the branch can help you clearly.
            The best bank account for foreigners in Korea is the one you can
            open smoothly and use without daily frustration.
          </p>
        </section>

        <GuideToProBridge
          lang={lang}
          tool={guideToPro['best-bank-account-for-foreigners-korea']}
        />

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            What to Prepare Before Opening a Bank Account
          </h2>

          <p className="leading-7 text-slate-700">
            Before visiting a bank in Korea, most international students should
            first prepare their basic documents, phone number, and
            residence-related details.
          </p>

          <ul className="list-disc pl-6 space-y-2 text-slate-700">
            <li>
              <a
                href={`/${lang}/arc-card-korea-guide`}
                className="text-blue-600 underline"
              >
                ARC Card Guide
              </a>
            </li>
            <li>
              <a
                href={`/${lang}/how-to-get-sim-card-in-korea`}
                className="text-blue-600 underline"
              >
                SIM Card Guide
              </a>
            </li>
            <li>
              <a
                href={`/${lang}/getting-started`}
                className="text-blue-600 underline"
              >
                Getting Started Guide
              </a>
            </li>
          </ul>
        </section>

        <section className="rounded-2xl bg-slate-900 p-6 text-white">
          <h2 className="text-2xl font-bold">Related Guides</h2>
          <p className="mt-3 text-slate-300">
            These pages will help you handle the rest of your early setup in
            Korea.
          </p>

          <div className="mt-4 flex flex-wrap gap-3">
            <a
              href={`/${lang}/arc-card-korea-guide`}
              className="rounded-xl bg-white px-4 py-2 font-semibold text-slate-900"
            >
              ARC Guide
            </a>
            <a
              href={`/${lang}/how-to-get-sim-card-in-korea`}
              className="rounded-xl border border-white/30 px-4 py-2 font-semibold text-white"
            >
              SIM Card Guide
            </a>
          </div>
        </section>
      </article>
      <RelatedPosts lang={lang as string} current="best-bank-account-for-foreigners-korea" />
      </main>
    </>
  );
}
