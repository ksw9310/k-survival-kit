import type { Metadata } from 'next';
import { isValidLocale, type Lang } from '@/lib/i18n';
import RelatedPosts from '@/components/RelatedPosts';
import { notFound } from 'next/navigation';
import PageHero from '@/components/PageHero';
import SectionGrid from '@/components/SectionGrid';
import { getDictionary } from '@/data';
import FirstWeekChecklist from '@/components/FirstWeekChecklist';
import GuideToProBridge from '@/components/GuideToProBridge';
import { getGuideToProMap } from '@/data/pro-tools';

/**
 * Design reminder for this file:
 * The public guide must end cleanly as an article.
 * The Pro invitation should appear as a deliberate transition after the guide content,
 * not as another card glued into the same reading flow.
 */

type Props = {
  params: Promise<{ lang: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { lang } = await params;

  if (!isValidLocale(lang)) {
    return {};
  }

  const content = getDictionary(lang).gettingStartedContent;

  return {
    title: `${content.title} | K-Survival Kit`,
    description: content.subtitle,
    alternates: {
      canonical: `https://k-survival-kit.vercel.app/${lang}/getting-started`,
      languages: {
        en: '/en/getting-started',
        zh: '/zh/getting-started',
        ru: '/ru/getting-started',
        ja: '/ja/getting-started',
      },
    },
    openGraph: {
      title: content.title,
      description: content.subtitle,
      url: `https://k-survival-kit.vercel.app/${lang}/getting-started`,
      locale: lang,
      type: 'website',
    },
  };
}

export default async function GettingStartedPage({ params }: Props) {
  const { lang } = await params;

  if (!isValidLocale(lang)) {
    notFound();
  }

  const content = getDictionary(lang).gettingStartedContent;
  const guideToPro = getGuideToProMap(lang as Lang);

  return (
    <main>
      <PageHero
        eyebrow={content.eyebrow}
        title={content.title}
        subtitle={content.subtitle}
      />

      <SectionGrid items={content.cards} />
      <FirstWeekChecklist />

      <section className="border-t border-slate-200 bg-slate-100 px-6 py-14 md:py-16">
        <div className="mx-auto max-w-6xl space-y-8">
          <div className="max-w-3xl">
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-slate-500">
              Public guide completed
            </p>
            <h2 className="mt-4 text-3xl font-bold tracking-tight text-slate-950 md:text-4xl">
              You have reached the end of the reading guide.
            </h2>
            <p className="mt-4 text-base leading-7 text-slate-600 md:text-lg">
              Everything above is designed to explain what matters during your first week in Korea. The section below is optional and belongs to a separate Pro workspace for users who want a trackable execution view.
            </p>
          </div>

          <GuideToProBridge lang={lang} tool={guideToPro['getting-started']} />
        </div>
      </section>

      <RelatedPosts lang={lang as string} current="getting-started" />
    </main>
  );
}
