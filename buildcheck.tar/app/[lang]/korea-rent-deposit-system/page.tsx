import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { isValidLocale } from '@/lib/i18n';
import ArticleHero from '@/components/ArticleHero';
import PageDisclaimer from '@/components/PageDisclaimer';
import RelatedPosts from '@/components/RelatedPosts';
import GuideToProBridge from '@/components/GuideToProBridge';
import { getGuideToProMap } from '@/data/pro-tools';

type Props = {
  params: Promise<{ lang: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { lang } = await params;

  if (!isValidLocale(lang)) {
    return {};
  }

  const url = `https://k-survival-kit.vercel.app/${lang}/korea-rent-deposit-system`;

  return {
    title:
      'Korea Rent Deposit System Guide (Jeonse, Wolse, Deposit) | K-Survival Kit',
    description:
      'Confused about Korea rent deposits? Learn the difference between jeonse and wolse, how much you need to pay, and what foreigners must check before signing a contract.',
    alternates: {
      canonical: url,
      languages: {
        en: '/en/korea-rent-deposit-system',
        zh: '/zh/korea-rent-deposit-system',
        ru: '/ru/korea-rent-deposit-system',
        ja: '/ja/korea-rent-deposit-system',
      },
    },
    openGraph: {
      title: 'Korea Rent Deposit System Guide',
      description:
        'Learn how jeonse, wolse, and housing deposits work in Korea before signing a rental contract.',
      url,
      type: 'article',
      siteName: 'K-Survival Kit',
      locale: lang,
    },
    twitter: {
      card: 'summary_large_image',
      title: 'Korea Rent Deposit System Guide',
      description:
        'Understand deposits, monthly rent, and rental contract basics in Korea.',
    },
  };
}

export default async function KoreaRentDepositSystemPage({ params }: Props) {
  const { lang } = await params;

  if (!isValidLocale(lang)) {
    notFound();
  }

  const guideToPro = getGuideToProMap(lang);

  return (
    <>
      <ArticleHero
        eyebrow="Housing / Rent Guide"
        title="Korea Rent Deposit System Explained (Jeonse, Wolse for Foreigners)"
        lead="The Korea rent deposit system can feel confusing if you are new to Korean housing. Many foreigners and international students are not used to paying a deposit before moving in, and the difference between jeonse and wolse can be hard to understand at first."
      />
      <PageDisclaimer type="general" />
      <main className="bg-slate-50 px-6 py-12">
      <article className="mx-auto max-w-4xl space-y-10">

        <section className="rounded-2xl border border-slate-200 bg-slate-50 p-6">
          <h2 className="text-2xl font-bold text-slate-900">Quick Answer</h2>
          <p className="mt-3 leading-7 text-slate-700">
            In Korea, most renters pay a deposit before moving in. Students
            usually deal with <strong>wolse</strong>, which means a deposit plus
            monthly rent. <strong>Jeonse</strong> involves a much larger deposit
            and usually no monthly rent, but it is often too expensive for most
            international students.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            What Is the Korea Rent Deposit System?
          </h2>

          <p className="leading-7 text-slate-700">
            The Korea rent deposit system is built around the idea that renters
            give the landlord a deposit before moving in. The size of that
            deposit can vary a lot depending on the type of contract, the area,
            and the condition of the property.
          </p>

          <p className="leading-7 text-slate-700">
            For international students, the deposit may feel unusual, but it is
            a normal part of the housing market in Korea.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">What Is Wolse?</h2>

          <p className="leading-7 text-slate-700">
            <strong>Wolse</strong> is the most common option for many students.
            It means you pay a deposit and also pay monthly rent.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Smaller deposit than jeonse</li>
            <li>Monthly rent is paid every month</li>
            <li>Common for one-room apartments and student housing</li>
            <li>Usually the most realistic option for foreigners</li>
          </ul>

          <p className="leading-7 text-slate-700">
            Example: you might pay a deposit plus a monthly rent amount for a
            small apartment near your university.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">What Is Jeonse?</h2>

          <p className="leading-7 text-slate-700">
            <strong>Jeonse</strong> is a system where you pay a very large
            deposit and usually do not pay monthly rent. It can be attractive in
            theory, but the deposit amount is often too high for most
            international students.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Very large upfront deposit</li>
            <li>Usually no monthly rent</li>
            <li>More common in long-term residential contracts</li>
            <li>Less practical for most students and short-term residents</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            What Is a Typical Deposit for Students?
          </h2>

          <p className="leading-7 text-slate-700">
            For international students, the deposit amount depends on the city,
            neighborhood, and housing type. One-room apartments, goshiwons, and
            shared housing all work differently.
          </p>

          <p className="leading-7 text-slate-700">
            In general, student-friendly places usually involve a lower deposit
            than family housing, but you should still confirm the exact amount
            and refund conditions before signing anything.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Why Deposits Matter
          </h2>

          <p className="leading-7 text-slate-700">
            The deposit is important because it is often a large amount of money
            for a student. If something goes wrong with the contract, getting
            the deposit back can become difficult.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Always check the contract carefully</li>
            <li>Confirm who receives the deposit</li>
            <li>Keep payment records</li>
            <li>Take photos before moving in</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            What Should Be in the Contract?
          </h2>

          <p className="leading-7 text-slate-700">
            Before paying a deposit, make sure the rental contract clearly shows
            the important details.
          </p>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Deposit amount</li>
            <li>Monthly rent amount</li>
            <li>Move-in and move-out dates</li>
            <li>Utility payment details</li>
            <li>Refund conditions</li>
            <li>Landlord or property details</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Common Risks for Foreigners
          </h2>

          <ul className="list-disc space-y-2 pl-6 text-slate-700">
            <li>Signing without fully understanding the contract</li>
            <li>Sending money before checking the property</li>
            <li>Not confirming deposit return conditions</li>
            <li>Relying only on verbal promises</li>
            <li>Not keeping copies of documents and receipts</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-slate-900">
            Best Housing Option for Most International Students
          </h2>

          <p className="leading-7 text-slate-700">
            For most students, the safest and most realistic option is usually a
            dormitory, a student-friendly one-room with wolse, or another
            housing arrangement with a manageable deposit.
          </p>

          <p className="leading-7 text-slate-700">
            Jeonse is important to understand, but in practice many students do
            not choose it because of the high upfront cost.
          </p>
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white p-6">
          <h2 className="text-2xl font-bold text-slate-900">Final Advice</h2>

          <p className="mt-3 leading-7 text-slate-700">
            The Korea rent deposit system is different from what many foreigners
            expect. Do not rush. Read the contract carefully, confirm the total
            cost, and choose a rental option that matches your real budget.
            Understanding jeonse, wolse, and deposits early can save you money
            and stress later.
          </p>
        </section>

        <GuideToProBridge
          lang={lang}
          tool={guideToPro['korea-rent-deposit-system']}
        />

        <section className="rounded-2xl bg-slate-900 p-6 text-white">
          <h2 className="text-2xl font-bold">Related Guides</h2>
          <p className="mt-3 text-slate-300">
            If you are preparing to live in Korea, these guides may also help.
          </p>

          <div className="mt-4 flex flex-wrap gap-3">
            <a
              href={`/${lang}/housing`}
              className="rounded-xl bg-white px-4 py-2 font-semibold text-slate-900"
            >
              Housing Guide
            </a>
            <a
              href={`/${lang}/getting-started`}
              className="rounded-xl border border-white/30 px-4 py-2 font-semibold text-white"
            >
              Getting Started
            </a>
          </div>
        </section>
      </article>
      <RelatedPosts lang={lang as string} current="korea-rent-deposit-system" />
      </main>
    </>
  );
}
