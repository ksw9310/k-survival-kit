import Link from 'next/link';
import { getDictionary } from '@/data';
import type { Lang } from '@/lib/i18n';

export default function Footer({ lang }: { lang: Lang }) {
  const t = getDictionary(lang).common;

  const links = [
    { href: `/${lang}/getting-started`, label: t.nav.gettingStarted },
    { href: `/${lang}/daily-life`, label: t.nav.dailyLife },
    { href: `/${lang}/health`, label: t.nav.health },
    { href: `/${lang}/housing`, label: t.nav.housing },
    { href: `/${lang}/culture`, label: t.nav.culture },
    { href: `/${lang}/visa`, label: t.nav.visa },
  ];

  return (
    <footer className="bg-slate-950 px-6 pt-12 pb-8 text-sm text-slate-400">
      <div className="mx-auto max-w-6xl">
        {/* Top row */}
        <div className="flex flex-col gap-8 md:flex-row md:items-start md:justify-between">
          {/* Brand */}
          <div className="max-w-xs">
            <p className="text-lg font-extrabold text-white">
              🎒 K-<span className="text-rose-400">Survival</span> Kit
            </p>
            <p className="mt-2 leading-6 text-slate-400">{t.footer.description}</p>
          </div>

          {/* Links */}
          <nav className="flex flex-wrap gap-x-6 gap-y-2">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-slate-400 transition-colors hover:text-rose-400"
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>

        {/* Divider */}
        <div className="my-8 border-t border-slate-800" />

        {/* Bottom row */}
        <div className="flex flex-col items-center gap-2 text-center text-xs text-slate-500 md:flex-row md:justify-between md:text-left">
          <div className="flex items-center gap-3">
            <p>© {new Date().getFullYear()} K-Survival Kit · Always Free</p>
            <span className="hidden text-slate-700 md:inline">·</span>
            <Link
              href={`/${lang}/about`}
              className="transition-colors hover:text-rose-400"
            >
              About
            </Link>
            <span className="hidden text-slate-700 md:inline">·</span>
            <Link
              href={`/${lang}/terms`}
              className="transition-colors hover:text-rose-400"
            >
              Terms of Use
            </Link>
          </div>
          <p className="max-w-md">{t.footer.disclaimer}</p>
        </div>
      </div>
    </footer>
  );
}
