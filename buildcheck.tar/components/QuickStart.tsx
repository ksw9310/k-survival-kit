import Link from 'next/link';
import { getGuideToProMap } from '@/data/pro-tools';
import type { Lang } from '@/lib/i18n';

type QuickStartProps = {
  lang: Lang;
};

type QuickItem = {
  href: string;
  proKey?: keyof ReturnType<typeof getGuideToProMap>;
  eyebrow: string;
  title: string;
  description: string;
  icon: string;
  accent: string;
  bg: string;
  border: string;
  eyebrowColor: string;
  iconBg: string;
  proLabel?: string;
};

const quickItems: QuickItem[] = [
  {
    href: '/getting-started',
    proKey: 'getting-started',
    eyebrow: 'New in Korea?',
    title: 'Start Here',
    description: 'SIM card, ARC, bank account basics',
    icon: '🚀',
    accent: 'from-rose-500 to-pink-500',
    bg: 'bg-rose-50',
    border: 'border-rose-100',
    eyebrowColor: 'text-rose-500',
    iconBg: 'bg-rose-100',
    proLabel: 'Open first-week Pro',
  },
  {
    href: '/housing',
    proKey: 'korea-rent-deposit-system',
    eyebrow: 'Looking for housing?',
    title: 'Find a Place',
    description: 'Deposits, rent, and contract basics',
    icon: '🏠',
    accent: 'from-blue-500 to-indigo-500',
    bg: 'bg-blue-50',
    border: 'border-blue-100',
    eyebrowColor: 'text-blue-500',
    iconBg: 'bg-blue-100',
    proLabel: 'Review housing Pro',
  },
  {
    href: '/daily-life',
    eyebrow: 'Need daily tips?',
    title: 'Daily Life',
    description: 'Transport, delivery apps, and essentials',
    icon: '🌆',
    accent: 'from-emerald-500 to-teal-500',
    bg: 'bg-emerald-50',
    border: 'border-emerald-100',
    eyebrowColor: 'text-emerald-600',
    iconBg: 'bg-emerald-100',
  },
];

export default function QuickStart({ lang }: QuickStartProps) {
  const proMap = getGuideToProMap(lang);

  return (
    <section className="mx-auto max-w-6xl px-6 py-12">
      <div className="grid gap-4 md:grid-cols-3">
        {quickItems.map((item) => {
          const proTool = item.proKey ? proMap[item.proKey] : undefined;

          return (
            <div
              key={item.href}
              className={`group relative overflow-hidden rounded-2xl border ${item.border} ${item.bg} p-6 shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg`}
            >
              <div className={`absolute left-0 right-0 top-0 h-1 bg-gradient-to-r ${item.accent}`} />

              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <p className={`text-sm font-semibold ${item.eyebrowColor}`}>{item.eyebrow}</p>
                  <h3 className="mt-1 text-xl font-bold text-slate-900">{item.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-slate-600">{item.description}</p>
                </div>
                <div className={`ml-4 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${item.iconBg} text-2xl`}>
                  {item.icon}
                </div>
              </div>

              <div className="mt-5 flex flex-wrap gap-2.5">
                <Link
                  href={`/${lang}${item.href}`}
                  className="inline-flex items-center rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-slate-800 ring-1 ring-slate-200 transition hover:bg-slate-50"
                >
                  Open guide
                </Link>

                {proTool && item.proLabel ? (
                  <Link
                    href={proTool.href}
                    className="inline-flex items-center rounded-xl bg-slate-950 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-slate-800"
                  >
                    {item.proLabel}
                  </Link>
                ) : null}
              </div>

              <div className={`mt-4 flex items-center gap-1 text-sm font-semibold ${item.eyebrowColor} opacity-0 transition-all group-hover:opacity-100`}>
                <span>{proTool ? 'Guide first, then Pro' : 'Learn more'}</span>
                <span className="transition-transform group-hover:translate-x-1">→</span>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
