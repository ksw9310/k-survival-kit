import Link from 'next/link';
import { getDictionary } from '@/data';
import { getGuideToProMap } from '@/data/pro-tools';
import type { Lang } from '@/lib/i18n';
import LanguageSwitcher from './LanguageSwitcher';

const navLinks = (lang: string, t: { nav: Record<string, string> }) => [
  { href: `/${lang}`, label: t.nav.home },
  { href: `/${lang}/getting-started`, label: t.nav.gettingStarted },
  { href: `/${lang}/daily-life`, label: t.nav.dailyLife },
  { href: `/${lang}/health`, label: t.nav.health },
  { href: `/${lang}/housing`, label: t.nav.housing },
  { href: `/${lang}/culture`, label: t.nav.culture },
  { href: `/${lang}/visa`, label: t.nav.visa },
];

export default function Navbar({ lang }: { lang: Lang }) {
  const t = getDictionary(lang).common;
  const proMap = getGuideToProMap(lang);

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/80 bg-white/95 shadow-sm backdrop-blur-sm">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3.5">
        {/* Logo */}
        <Link
          href={`/${lang}`}
          className="flex items-center gap-1.5 text-xl font-extrabold text-slate-900 transition-opacity hover:opacity-80"
        >
          <span className="text-2xl">🎒</span>
          K-<span className="text-rose-500">Survival</span> Kit
        </Link>

        {/* Nav links */}
        <div className="hidden gap-1 md:flex">
          {navLinks(lang, t).map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="rounded-lg px-3 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-rose-50 hover:text-rose-600"
            >
              {link.label}
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <Link
            href={proMap['getting-started'].href}
            className="hidden rounded-lg bg-slate-900 px-3 py-2 text-sm font-semibold text-white transition hover:bg-rose-600 md:inline-flex"
          >
            Pro
          </Link>
          <LanguageSwitcher currentLang={lang} />
        </div>
      </nav>
    </header>
  );
}
