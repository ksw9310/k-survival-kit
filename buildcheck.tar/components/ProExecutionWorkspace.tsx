'use client';

/**
 * Design reminder for this file:
 * Pro is a dedicated execution workspace, not an extension of the article body.
 * The UI should feel like a calm operational desk with strong information hierarchy,
 * persistent progress visibility, and clear separation between explanation and action.
 */

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import type { ProTool } from '@/data/pro-tools';

type ProExecutionWorkspaceProps = {
  lang: string;
  tool: ProTool;
  relatedTools: ProTool[];
};

type StoredWorkspaceState = {
  checked: string[];
  note: string;
  updatedAt: string | null;
};

const storagePrefix = 'k-survival-kit-pro-workspace';

function getStorageKey(slug: string) {
  return `${storagePrefix}:${slug}`;
}

export default function ProExecutionWorkspace({
  lang,
  tool,
  relatedTools,
}: ProExecutionWorkspaceProps) {
  const essentialTasks = useMemo(
    () => tool.tasks.filter((task) => !task.optional),
    [tool.tasks],
  );
  const taskMap = useMemo(
    () => new Map(tool.tasks.map((task) => [task.id, task])),
    [tool.tasks],
  );

  const [checkedIds, setCheckedIds] = useState<string[]>([]);
  const [note, setNote] = useState('');
  const [hydrated, setHydrated] = useState(false);
  const [lastSavedAt, setLastSavedAt] = useState<string | null>(null);

  useEffect(() => {
    const raw = window.localStorage.getItem(getStorageKey(tool.slug));

    if (raw) {
      try {
        const parsed = JSON.parse(raw) as StoredWorkspaceState;
        setCheckedIds(Array.isArray(parsed.checked) ? parsed.checked : []);
        setNote(typeof parsed.note === 'string' ? parsed.note : '');
        setLastSavedAt(parsed.updatedAt ?? null);
      } catch {
        window.localStorage.removeItem(getStorageKey(tool.slug));
      }
    }

    setHydrated(true);
  }, [tool.slug]);

  useEffect(() => {
    if (!hydrated) {
      return;
    }

    const payload: StoredWorkspaceState = {
      checked: checkedIds,
      note,
      updatedAt: new Date().toISOString(),
    };

    window.localStorage.setItem(getStorageKey(tool.slug), JSON.stringify(payload));
    setLastSavedAt(payload.updatedAt);
  }, [checkedIds, note, hydrated, tool.slug]);

  const essentialCompleted = essentialTasks.filter((task) => checkedIds.includes(task.id)).length;
  const totalCompleted = tool.tasks.filter((task) => checkedIds.includes(task.id)).length;
  const progressPercent = essentialTasks.length
    ? Math.round((essentialCompleted / essentialTasks.length) * 100)
    : 0;

  const saveStateLabel = hydrated ? 'Saved on this device' : 'Loading your workspace';
  const lastSavedLabel = lastSavedAt
    ? new Intl.DateTimeFormat('en', {
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
      }).format(new Date(lastSavedAt))
    : 'Not saved yet';

  function toggleTask(taskId: string) {
    setCheckedIds((current) =>
      current.includes(taskId)
        ? current.filter((id) => id !== taskId)
        : [...current, taskId],
    );
  }

  function resetWorkspace() {
    setCheckedIds([]);
    setNote('');
    setLastSavedAt(new Date().toISOString());
    window.localStorage.removeItem(getStorageKey(tool.slug));
  }

  return (
    <section className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
      <div className="space-y-6">
        <section className="overflow-hidden rounded-[2rem] border border-slate-200 bg-white shadow-sm">
          <div className="border-b border-slate-200 bg-[linear-gradient(135deg,#0f172a_0%,#172554_52%,#111827_100%)] px-6 py-7 text-white md:px-8 md:py-8">
            <div className="flex flex-wrap items-center gap-3">
              <span className="rounded-full border border-white/15 bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-slate-100">
                Pro workspace
              </span>
              <span className="rounded-full border border-emerald-300/30 bg-emerald-300/10 px-3 py-1 text-xs font-semibold text-emerald-100">
                {saveStateLabel}
              </span>
            </div>
            <h2 className="mt-5 max-w-3xl text-3xl font-bold tracking-tight md:text-4xl">
              Work through the real tasks and keep your place.
            </h2>
            <p className="mt-4 max-w-3xl text-base leading-7 text-slate-200 md:text-lg">
              {tool.executionSummary}
            </p>
          </div>

          <div className="grid gap-4 border-b border-slate-200 bg-slate-50 p-6 md:grid-cols-3 md:p-8">
            <div className="rounded-2xl border border-slate-200 bg-white p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
                Essential progress
              </p>
              <p className="mt-4 text-4xl font-bold tracking-tight text-slate-950">
                {progressPercent}%
              </p>
              <p className="mt-2 text-sm leading-6 text-slate-600">
                {essentialCompleted} of {essentialTasks.length} core tasks completed.
              </p>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
                Workspace status
              </p>
              <p className="mt-4 text-xl font-semibold text-slate-950">
                {tool.readinessLabel}
              </p>
              <p className="mt-2 text-sm leading-6 text-slate-600">
                {tool.readinessDescription}
              </p>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5">
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
                Last saved
              </p>
              <p className="mt-4 text-xl font-semibold text-slate-950">{lastSavedLabel}</p>
              <p className="mt-2 text-sm leading-6 text-slate-600">
                Your checklist and notes stay on this browser even if you leave the page.
              </p>
            </div>
          </div>

          <div className="p-6 md:p-8">
            <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
              <div className="max-w-3xl">
                <p className="text-xs font-semibold uppercase tracking-[0.22em] text-rose-500">
                  Action checklist
                </p>
                <h3 className="mt-3 text-2xl font-bold tracking-tight text-slate-950 md:text-3xl">
                  Finish the tasks that move this topic forward.
                </h3>
                <p className="mt-3 text-base leading-7 text-slate-600">
                  Unlike the public guide, this page is designed for execution. Check off what is done, leave yourself notes, and come back later without losing progress.
                </p>
              </div>
              <button
                type="button"
                onClick={resetWorkspace}
                className="inline-flex rounded-2xl border border-slate-300 px-4 py-3 text-sm font-semibold text-slate-700 transition hover:border-slate-400 hover:bg-slate-50"
              >
                Reset this workspace
              </button>
            </div>

            <div className="mt-8 space-y-4">
              {tool.tasks.map((task, index) => {
                const checked = checkedIds.includes(task.id);
                const relatedStep = taskMap.get(task.id)?.stepHint;

                return (
                  <label
                    key={task.id}
                    className={`grid cursor-pointer gap-4 rounded-[1.5rem] border p-5 transition md:grid-cols-[auto_1fr] md:items-start ${
                      checked
                        ? 'border-emerald-200 bg-emerald-50/80'
                        : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/80'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleTask(task.id)}
                        className="mt-1 h-5 w-5 rounded border-slate-300 text-slate-950 focus:ring-slate-400"
                      />
                      <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-slate-950 text-sm font-bold text-white">
                        {index + 1}
                      </div>
                    </div>
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="text-lg font-semibold text-slate-950">{task.title}</h4>
                        {task.optional ? (
                          <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600">
                            Optional
                          </span>
                        ) : (
                          <span className="rounded-full bg-rose-50 px-2.5 py-1 text-xs font-semibold text-rose-600">
                            Core task
                          </span>
                        )}
                      </div>
                      <p className="mt-2 text-sm leading-6 text-slate-600">{task.description}</p>
                      {relatedStep ? (
                        <p className="mt-3 text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">
                          Supports step: {relatedStep}
                        </p>
                      ) : null}
                    </div>
                  </label>
                );
              })}
            </div>
          </div>
        </section>

        <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm md:p-8">
          <div className="max-w-3xl">
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-slate-500">
              Working notes
            </p>
            <h3 className="mt-3 text-2xl font-bold tracking-tight text-slate-950 md:text-3xl">
              Keep the details you do not want to forget.
            </h3>
            <p className="mt-3 text-base leading-7 text-slate-600">
              Use this space for branch names, document reminders, questions for your landlord, or anything else you need during the task.
            </p>
          </div>

          <textarea
            value={note}
            onChange={(event) => setNote(event.target.value)}
            placeholder={tool.notePlaceholder}
            className="mt-6 min-h-[180px] w-full rounded-[1.5rem] border border-slate-200 bg-slate-50 px-5 py-4 text-sm leading-7 text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-slate-400 focus:bg-white"
          />
        </section>
      </div>

      <aside className="space-y-6">
        <section className="rounded-[2rem] bg-slate-950 p-6 text-white shadow-sm md:p-8">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-amber-300">
            Execution sequence
          </p>
          <ol className="mt-6 space-y-4">
            {tool.steps.map((step, index) => (
              <li
                key={step.title}
                className="rounded-2xl border border-white/10 bg-white/[0.04] p-4"
              >
                <div className="flex items-start gap-3">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-rose-400/15 text-sm font-bold text-rose-200">
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-semibold text-white">{step.title}</p>
                    <p className="mt-2 text-sm leading-6 text-slate-300">{step.body}</p>
                  </div>
                </div>
              </li>
            ))}
          </ol>
        </section>

        <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm md:p-8">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-500">
            Completion snapshot
          </p>
          <div className="mt-4 h-3 overflow-hidden rounded-full bg-slate-200">
            <div
              className="h-full rounded-full bg-slate-950 transition-all"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <p className="mt-4 text-sm leading-6 text-slate-600">
            You have completed <span className="font-semibold text-slate-950">{totalCompleted}</span> of{' '}
            <span className="font-semibold text-slate-950">{tool.tasks.length}</span> tasks in this workspace.
          </p>

          <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <p className="text-sm font-semibold text-slate-900">Why the public guide still matters</p>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              The guide remains the best place for explanations, caveats, and policy context. This workspace is for action and memory.
            </p>
          </div>

          <div className="mt-6 grid gap-3">
            <Link
              href={`/${lang}${tool.guideHref}`}
              className="inline-flex items-center justify-center rounded-2xl border border-slate-300 px-4 py-3 text-sm font-semibold text-slate-700 transition hover:border-slate-400 hover:bg-slate-50"
            >
              Return to public guide
            </Link>
            {tool.nextToolSlug ? (
              <Link
                href={`/${lang}/pro/${tool.nextToolSlug}`}
                className="inline-flex items-center justify-center rounded-2xl bg-slate-950 px-4 py-3 text-sm font-semibold text-white transition hover:bg-slate-800"
              >
                Continue to {tool.nextToolTitle}
              </Link>
            ) : null}
          </div>
        </section>

        <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm md:p-8">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-slate-500">
            Related Pro pages
          </p>
          <div className="mt-5 space-y-3">
            {relatedTools.map((related) => (
              <Link
                key={related.slug}
                href={`/${lang}/pro/${related.slug}`}
                className="block rounded-2xl border border-slate-200 bg-slate-50 p-4 transition hover:border-slate-300 hover:bg-white"
              >
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-rose-500">
                  {related.eyebrow}
                </p>
                <h3 className="mt-2 text-base font-semibold text-slate-900">{related.title}</h3>
                <p className="mt-2 text-sm leading-6 text-slate-600">{related.summary}</p>
              </Link>
            ))}
          </div>
        </section>
      </aside>
    </section>
  );
}
